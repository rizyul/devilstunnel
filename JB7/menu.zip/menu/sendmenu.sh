#!/bin/bash
GITHUB_CMD="https://github.com/Rolka111111/gif/raw/"
wget -O /usr/bin/add-ss "${GITHUB_CMD}main/fodder/nginx/add-ss" >/dev/null 2>&1
wget -O /usr/bin/add-ssh "${GITHUB_CMD}main/fodder/nginx/add-ssh" >/dev/null 2>&1
wget -O /usr/bin/add-vless "${GITHUB_CMD}main/fodder/nginx/add-vless" >/dev/null 2>&1
wget -O /usr/bin/add-ws "${GITHUB_CMD}main/fodder/nginx/add-ws" >/dev/null 2>&1
wget -O /usr/bin/add-tr "${GITHUB_CMD}main/fodder/nginx/add-tr" >/dev/null 2>&1
wget -O /usr/bin/cek-ss "${GITHUB_CMD}main/fodder/nginx/cek-ss" >/dev/null 2>&1
wget -O /usr/bin/cek-ssh "${GITHUB_CMD}main/fodder/nginx/cek-ssh" >/dev/null 2>&1
wget -O /usr/bin/cek-vless "${GITHUB_CMD}main/fodder/nginx/cek-vless" >/dev/null 2>&1
wget -O /usr/bin/cek-ws "${GITHUB_CMD}main/fodder/nginx/cek-ws" >/dev/null 2>&1
wget -O /usr/bin/cek-tr "${GITHUB_CMD}main/fodder/nginx/cek-tr" >/dev/null 2>&1
wget -O /usr/bin/del-ss "${GITHUB_CMD}main/fodder/nginx/del-ss" >/dev/null 2>&1
wget -O /usr/bin/del-ssh "${GITHUB_CMD}main/fodder/nginx/del-ssh" >/dev/null 2>&1
wget -O /usr/bin/del-vless "${GITHUB_CMD}main/fodder/nginx/del-vless" >/dev/null 2>&1
wget -O /usr/bin/del-ws "${GITHUB_CMD}main/fodder/nginx/del-ws" >/dev/null 2>&1
wget -O /usr/bin/del-tr "${GITHUB_CMD}main/fodder/nginx/del-tr" >/dev/null 2>&1
wget -O /usr/bin/renew-ss "${GITHUB_CMD}main/fodder/nginx/renew-ss" >/dev/null 2>&1
wget -O /usr/bin/renew-ssh "${GITHUB_CMD}main/fodder/nginx/renew-ssh" >/dev/null 2>&1
wget -O /usr/bin/renew-vless "${GITHUB_CMD}main/fodder/nginx/renew-vless" >/dev/null 2>&1
wget -O /usr/bin/renew-ws "${GITHUB_CMD}main/fodder/nginx/renew-ws" >/dev/null 2>&1
wget -O /usr/bin/renew-tr "${GITHUB_CMD}main/fodder/nginx/renew-tr" >/dev/null 2>&1
wget -O /usr/bin/menu "${GITHUB_CMD}main/fodder/nginx/menu" >/dev/null 2>&1
wget -O /usr/bin/run "${GITHUB_CMD}main/fodder/nginx/run" >/dev/null 2>&1
wget -O /usr/bin/seres "${GITHUB_CMD}main/fodder/nginx/seres" >/dev/null 2>&1
wget -O /usr/bin/shadowsocks "${GITHUB_CMD}main/fodder/nginx/shadowsocks" >/dev/null 2>&1
wget -O /usr/bin/trojan "${GITHUB_CMD}main/fodder/nginx/trojan" >/dev/null 2>&1
wget -O /usr/bin/vless "${GITHUB_CMD}main/fodder/nginx/vless" >/dev/null 2>&1
wget -O /usr/bin/vmess "${GITHUB_CMD}main/fodder/nginx/vmess" >/dev/null 2>&1
wget -O /usr/bin/ssh "${GITHUB_CMD}main/fodder/nginx/ssh" >/dev/null 2>&1
wget -O /usr/bin/xp "${GITHUB_CMD}main/fodder/nginx/xp" >/dev/null 2>&1
wget -O /usr/bin/get-backres "${GITHUB_CMD}main/fodder/nginx/get-backres" >/dev/null 2>&1
wget -O /usr/bin/get-domain "${GITHUB_CMD}main/fodder/nginx/get-domain" >/dev/null 2>&1
wget -O /usr/bin/ittil.bak "${GITHUB_CMD}main/fodder/nginx/ittil.bak" >/dev/null 2>&1
wget -O /usr/bin/logclean "${GITHUB_CMD}main/fodder/nginx/logclean" >/dev/null 2>&1
wget -O /usr/bin/portin "${GITHUB_CMD}main/fodder/nginx/portin" >/dev/null 2>&1
chmod +x /usr/bin/add-ss
chmod +x /usr/bin/add-ssh
chmod +x /usr/bin/add-vless
chmod +x /usr/bin/add-ws
chmod +x /usr/bin/add-tr
chmod +x /usr/bin/cek-ss
chmod +x /usr/bin/cek-ssh
chmod +x /usr/bin/cek-vless
chmod +x /usr/bin/cek-ws
chmod +x /usr/bin/cek-tr
chmod +x /usr/bin/renew-ss
chmod +x /usr/bin/renew-ssh
chmod +x /usr/bin/renew-vless
chmod +x /usr/bin/renew-ws
chmod +x /usr/bin/renew-tr
chmod +x /usr/bin/del-ss
chmod +x /usr/bin/del-ssh
chmod +x /usr/bin/del-vless
chmod +x /usr/bin/del-ws
chmod +x /usr/bin/del-tr
chmod +x /usr/bin/menu
chmod +x /usr/bin/run
chmod +x /usr/bin/seres
chmod +x /usr/bin/shadowsocks
chmod +x /usr/bin/trojan
chmod +x /usr/bin/vless
chmod +x /usr/bin/vmess
chmod +x /usr/bin/xp
chmod +x /usr/bin/get-backres
chmod +x /usr/bin/get-domain
chmod +x /usr/bin/ittil.bak
chmod +x /usr/bin/logclean
chmod +x /usr/bin/portin
